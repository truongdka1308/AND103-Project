const { error } = require('console');
const express=require('express');
const mailer=require('nodemailer');
const app43=express();

let transporter=mailer.createTransport({
    service: 'gmail',
    auth:{
        user:'truongngv1308@gmail.com',
        pass:'ogib gpar yovh xzez'
    }
});

let mailOption={
    from:'truongngv1308@gmail.com',
    to:'truongnvph39018@fpt.edu.vn',
    subject:'test gui mail',
    text:'day la email gui ngay 19/7'
};
transporter.sendMail(mailOption,(error,info)=>{
    if (error) {
        console.error(error);
    }
    else{
        console.log("Thanh cong",info.messageId);
    }
});

app43.listen(3002,()=>{
    console.log('Server dang chay o cong 3002');
})