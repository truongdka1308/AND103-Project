const express=require('express');
const jwt=require('jsonwebtoken');
const bodyparser=require('body-parser');

const app44=express();

app44.use(bodyparser.urlencoded({extended:true}));
app44.use(bodyparser.json());

const accessTokenSecret='123456';
const refreshTokenSecret='123456';

const users=[
    {id:1,username:'user123',password:'password'},
];

function generateAcessToken(user){
    return jwt.sign(user,accessTokenSecret,{expiresIn:'15m'});
}

function generateRefressToken(user){
    return jwt.sign(user,refreshTokenSecret,{expiresIn:'7d'});
}

app44.post('/login', (req,res)=>{
    const { username, password } = req.body; //nhap user, pass qua postman
    console.log(username);
    console.log(password);
    //validate thong tin user nhap
    const user=users.find((u)=>
        u.username===username && u.password===password
    );
    if(!user){
        console.log("user, pass khong dung");
        return;
    }
    //neu du lieu nhap dung -> ta tao token
    const accessToken=generateAcessToken({id:user.id,username: user.username});
    const refessToken=generateRefressToken({id:user.id,username: user.username});
    //tra ve ket qua
    res.json({accessToken,refessToken});
    console.log("AccessToken: ",accessToken);
    console.log("RefressToken: ",refessToken);
    //
});
//lang nghe
app44.listen(3004,()=>{
    console.log("server dang chay o cong 3004");
});