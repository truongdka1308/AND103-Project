const express=require('express');
const mongoose=require('mongoose');
const student=require('./studentModel');
//create object express
const app=express();
app.set('view engine','ejs');
mongoose.connect('mongodb://localhost:27017/AND103',{
    useNewURLParser:true,
    useUnifiedTopology:true,
}).then(()=>{
    console.log("Ket noi thanh cong vs mongodb")
}).catch((err)=>{
    console.error(err);
});
//When user call localhost:300/sinhvien=>read data from CSDL
app.get('/student',async(req,res)=>{
    try {
        const students=await student.find();
        //res.json(students);//chuyen sang dang json
        res.render('students',{students:students});
        console.log(students);
    } catch (error) {
        console.error(error);
        res.status(500).json({error:'Internal Server Error'});
    }
});
//tao cong dich vu
const PORT=process.env.PORT || 3000;
//server lang nghe
app.listen(PORT,()=>{
    console.log(`server dang chay o cong:${PORT}`);
})