<?php
$rey=array();
$s="localhost"; $u="root";$p="";$db="a1";

$con=new mysqli($s,$u,$p,$db);
$MaSP=$_POST['MaSP'];
$TenSP=$_POST['TenSP'];
$MoTa=$_POST['MoTa'];
$sql="UPDATE sanpham SET TenSP='$TenSP',MoTa='$MoTa' WHERE MaSP='$MaSP'";

if($con->query($sql)===TRUE){
    $res['success']=1;
    $res['message']="update thanh cong";
    echo json_encode($res);
}
else{
    $res['success']=0;
    $res['message']="update that bai";
    echo json_encode($res);
}

$con->close();
//http://localhost/000/2024071/insert.php?MaSP=SP2&TenSP=san pham 2&MoTa=mo ta san pham 3