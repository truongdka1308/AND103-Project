package com.example.demolab1_and103.demo5.select;

import com.example.demolab1_and103.demo5.SanPham;

public class SvrResponseSelect {
    private SanPham[] products;
    private String message;

    public SanPham[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
