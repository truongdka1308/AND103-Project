<?php
$rey=array();
$s="localhost"; $u="root";$p="";$db="a1";

$con=new mysqli($s,$u,$p,$db);
$sql="SELECT * FROM sanpham";
$result=$con->query($sql);
if($result->num_rows>0){
    $res['products']=array();
    while($row=$result->fetch_assoc()){
        $product=array();
        $product['MaSP']=$row['MaSP'];
        $product['TenSP']=$row['TenSP'];
        $product['MoTa']=$row['MoTa'];
        array_push($res['products'],$product);
    }
    $res['success']=1;
    $res['message']="select thanh cong";
    echo json_encode($res);
}
else{
    $res['success']=0;
    $res['message']="khong co du lieu";
    echo json_encode($res);
}

$con->close();
//http://localhost/000/2024071/insert.php?MaSP=SP2&TenSP=san pham 2&MoTa=mo ta san pham 3