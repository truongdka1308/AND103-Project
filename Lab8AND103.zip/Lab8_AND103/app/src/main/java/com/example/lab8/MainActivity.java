package com.example.lab8;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    Button btn1, btn2, btn3, btn4;
    TextView tvKq;
    EditText txt1, txt2, txt3;
    Context context = this;
    String strKQ = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btn1 = findViewById(R.id.button1);
        btn2 = findViewById(R.id.button2);
        btn3 = findViewById(R.id.button3);
        btn4 = findViewById(R.id.button4);
        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        txt3 = findViewById(R.id.txt3);
        tvKq = findViewById(R.id.tvKq);

        btn1.setOnClickListener(v -> {
            selectVolley();
        });
        btn2.setOnClickListener(v -> {
            insertVolley();
        });
        btn3.setOnClickListener(v -> {
            updateVolley();
        });
        btn4.setOnClickListener(v -> {
            deleteVolley();
        });
    }

    private void selectVolley() {
        strKQ="";
        tvKq.setText("");

        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "https://hungnq28.000webhostapp.com/su2024/select.php";
        JsonObjectRequest request = new JsonObjectRequest(url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("products");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject p = jsonArray.getJSONObject(i);
                        String maSP = p.getString("MaSP");
                        String tenSP = p.getString("TenSP");
                        String mota = p.getString("MoTa");
                        strKQ += "MaSP: " + maSP + "TenSP: " + tenSP + "Mo ta: " + mota + "\n" + "-----------------------------------" + "\n";
                    }
                    tvKq.setText(strKQ);
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
                ;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvKq.setText(error.getMessage());
            }
        });
        queue.add(request);

    }

    private void updateVolley() {
        // 1. Chuẩn bị dữ liệu
        String maSp = txt1.getText().toString();
        String tenSp = txt2.getText().toString();
        String moTa = txt3.getText().toString();

        // 2. Tạo RequestQueue
        RequestQueue queue = Volley.newRequestQueue(context);

        // 3. URL
        String url = "https://hungnq28.000webhostapp.com/su2024/update.php";

        // 4. Tạo StringRequest
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    // Xử lý khi thành công
                    tvKq.setText("Cap nhat thanh cong: " + response);
                },
                error -> {
                    // Xử lý khi có lỗi
                    tvKq.setText("Cat nhat that bai: " + error.toString());
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                // 5. Truyền tham số cho request
                Map<String, String> params = new HashMap<>();
                params.put("MaSP", maSp);
                params.put("TenSP", tenSp);
                params.put("MoTa", moTa);
                return params;
            }
        };

        // 6. Thêm request vào RequestQueue
        queue.add(request);
    }

    private void insertVolley() {
        String maSp = txt1.getText().toString();
        String tenSp = txt2.getText().toString();
        String moTa = txt3.getText().toString();

        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "https://hungnq28.000webhostapp.com/su2024/insert.php";

        StringRequest request = new StringRequest(Request.Method.POST, url, response -> {
            tvKq.setText("Them thanh cong: " + response);
        }, error -> {
            tvKq.setText("Them that bai: " + error.toString());
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();
                params.put("MaSP", maSp);
                params.put("TenSP", tenSp);
                params.put("MoTa", moTa);
                return params;
            }
        };

        queue.add(request);

    }

    private void deleteVolley() {
        // 1. cbi du lieu
//        String maSp = txt1.getText().toString();
        // 2. tao queue
        RequestQueue queue = Volley.newRequestQueue(context);
        // 3. url
        String url = "https://hungnq28.000webhostapp.com/su2024/delete.php";
        // 4. Xac dinh loai request
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                tvKq.setText(response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvKq.setText(error.getMessage());
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> mydata = new HashMap<>();
                mydata.put("MaSP", txt1.getText().toString());
                return mydata;
            }
        };
        queue.add(request);
    }
}

