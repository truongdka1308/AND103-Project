package com.example.demolab1_and103.demo5;

public class SvrResponseSanPham {
    private SanPham sanphams;

    private String message;

    public SanPham getSanphams() {
        return sanphams;
    }

    public void setSanphams(SanPham sanphams) {
        this.sanphams = sanphams;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
