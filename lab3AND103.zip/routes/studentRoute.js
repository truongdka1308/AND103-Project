const express=require('express');
const router=express.Router();
const student=require('../models/studentModel');

//GET
router.get('/',async (req,res)=>{
    try{
        const students=await student.find();
        // res.json(students);//tra ve json
        res.render('students',{students:students});
        console.log(students);
    }catch(err){
        console.error(err);
        res.status(500).json({error:'Khong ket noi duoc voi server'});
    }
});

//POST: tao moi 1 stu
//http://localhost:3000/student
router.post('/',async (req,res)=>{
    try {
        const {id,name}=req.body;
        const student1=new student({id,name});
        await student1.save();
        res.status(201).json(student1);
        console.log(student1);
    } catch (error) {
        console.error(error);
        res.status(500).json({error:"Khong ket noi duoc voi server"});
    }
});

//PUT:update thong tin sv
//http://localhost:3000/student/:_id
router.put('/:_id',async(req,res)=>{
    try{
        const {_id}=req.params;
        const {name,id}=req.body;
        const updateStudent=await student.findByIdAndUpdate(_id,{id,name},{new:true});
        res.json(updateStudent);
console.log(updateStudent);
    }catch(error){
        console.error(error);
        res.status(500).json({error:"Khong ket noi duoc voi server"})
    }
});

module.exports=router;
