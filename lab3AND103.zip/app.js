const express=require('express');
const mongoose=require('mongoose');
const studentRoute=require('./routes/studentRoute');
const bodyParser = require('body-parser');

const app=express();
app.set('view engine','ejs');
mongoose.connect('mongodb://localhost:27017/AND103',{
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(()=>{
    console.log("ket noi thanh cong voi mongodb");
}).catch((err)=>{
    console.error("Loi ket noi:",err);
});

app.use(bodyParser.urlencoded({extended:false}));
app.use(express.json());


app.use('/student',studentRoute);
app.use('/',studentRoute);
const PORT=process.env.PORT || 3000;
app.listen(PORT,()=>{
    console.log("Server dang chay o cong 3000");
});