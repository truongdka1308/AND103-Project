package com.example.demolab1_and103;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.android.volley.toolbox.JsonObjectRequest;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Demo7MainActivity2 extends AppCompatActivity {
    EditText txt1, txt2, txt3;
    Button btnSelect, button2;
    TextView tvkq;
    Context context= this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_demo7_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txt1 = findViewById(R.id.edittext1);
        txt2 = findViewById(R.id.edittext2);
        txt3 = findViewById(R.id.edittext3);
        tvkq = findViewById(R.id.txtkq);
        btnSelect = findViewById(R.id.btnselect);
        button2 = findViewById(R.id.button2);

        btnSelect.setOnClickListener(v -> {
            selectVolley();
        });

        button2.setOnClickListener(v -> {

        });
    }

    String strKQ = "";

    private void selectVolley() {
        strKQ = "";
        RequestQueue queue = Volley.newRequestQueue(context);

        String url = "https://hungnq28.000webhostapp.com/su2024/select.php";

        JsonObjectRequest request = new JsonObjectRequest(url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("products");
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject p = jsonArray.getJSONObject(i);
                        String maSP = p.getString("MaSP");
                        String tenSP = p.getString("TenSP");
                        String mota = p.getString("MoTa");

                        strKQ += "MaSP: " + maSP + "TenSP: " + tenSP + "Mo ta: " + mota+"\n";

                    }
                    tvkq.setText(strKQ);
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvkq.setText(error.getMessage());
            };
        });

        queue.add(request);
    }
}